
import { GoogleGenAI, Type } from "@google/genai";

// Fixed: Corrected initialization to use process.env.API_KEY directly per SDK guidelines
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateQuizFromTopic = async (topic: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a 5-question multiple choice quiz about: ${topic}. Provide the response in JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          category: { type: Type.STRING },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                text: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                correctAnswer: { type: Type.INTEGER, description: 'Index of correct option (0-3)' }
              },
              required: ['id', 'text', 'options', 'correctAnswer']
            }
          }
        },
        required: ['title', 'description', 'questions', 'category']
      }
    }
  });

  return JSON.parse(response.text);
};

export const chatWithGemini = async (history: { role: string, parts: { text: string }[] }[]) => {
  const ai = getAI();
  const model = 'gemini-3-flash-preview';
  
  const response = await ai.models.generateContent({
    model,
    contents: history as any,
    config: {
      systemInstruction: "You are the PQP Portal AI assistant. Help users with quizzes, education, and portal navigation. Keep responses concise and helpful.",
    }
  });

  return response.text;
};

export const analyzeFormFeedback = async (feedback: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this user feedback for our portal and categorize it as Positive, Negative, or Neutral. Suggest one action item. Feedback: ${feedback}`,
  });
  return response.text;
};
