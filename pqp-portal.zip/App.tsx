
import React, { useState, useEffect } from 'react';
import { User, UserRole, Quiz } from './types';
import Navbar from './components/Navbar';
import AIChat from './components/AIChat';
import QuizPlayer from './components/QuizPlayer';
import AdminDashboard from './components/AdminDashboard';
import { generateQuizFromTopic, analyzeFormFeedback } from './services/geminiService';
// Fixed: Added Sparkles to the lucide-react import list
import { Brain, FileText, MessageSquare, Shield, CheckCircle2, ChevronRight, Loader2, LogIn, Lock, Mail, User as UserIcon, Sparkles } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoginView, setIsLoginView] = useState(true);
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' });
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [quizLoading, setQuizLoading] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [analysisResult, setAnalysisResult] = useState('');

  // Local state persistence simulation
  useEffect(() => {
    const savedUser = localStorage.getItem('pqp_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulation: Admin check or standard user
    const isAdmin = authForm.email.includes('admin');
    const userData: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: authForm.name || (isAdmin ? 'Admin User' : 'Standard User'),
      email: authForm.email,
      role: isAdmin ? UserRole.ADMIN : UserRole.USER
    };
    setUser(userData);
    localStorage.setItem('pqp_user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('pqp_user');
    setActiveTab('dashboard');
    setActiveQuiz(null);
  };

  const handleGenerateQuiz = async (topic: string) => {
    setQuizLoading(true);
    try {
      const quiz = await generateQuizFromTopic(topic);
      setActiveQuiz(quiz);
      setActiveTab('quiz-player');
    } catch (error) {
      alert("Failed to generate quiz. Check API key.");
    } finally {
      setQuizLoading(false);
    }
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;
    setAnalysisResult('Analyzing feedback with Gemini...');
    const result = await analyzeFormFeedback(feedback);
    setAnalysisResult(result);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full mx-auto bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-3xl mx-auto mb-4 shadow-lg">P</div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">PQP Portal</h2>
            <p className="mt-2 text-sm text-slate-500">Prashn-Uttar Portal for Next-Gen Learning</p>
          </div>

          <form className="space-y-6" onSubmit={handleAuth}>
            {!isLoginView && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input
                    type="text"
                    required
                    value={authForm.name}
                    onChange={(e) => setAuthForm({ ...authForm, name: e.target.value })}
                    className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="John Doe"
                  />
                </div>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="email"
                  required
                  value={authForm.email}
                  onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                  className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="name@example.com"
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">Hint: Use 'admin' in email for Admin role</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="password"
                  required
                  className="block w-full pl-10 pr-3 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all"
            >
              {isLoginView ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button
              onClick={() => setIsLoginView(!isLoginView)}
              className="text-sm font-medium text-indigo-600 hover:text-indigo-500 transition-colors"
            >
              {isLoginView ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-12">
      <Navbar user={user} activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-10">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Welcome back, {user.name}!</h1>
                <p className="text-slate-500">Here's what's happening today in your learning portal.</p>
              </div>
              <button 
                onClick={() => setActiveTab('quizzes')}
                className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
              >
                <Brain className="w-5 h-5" /> Start Learning
              </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-indigo-600 to-purple-700 p-6 rounded-2xl shadow-lg text-white">
                <h3 className="text-lg font-bold mb-2">PQP AI Assistant</h3>
                <p className="text-indigo-100 text-sm mb-6">Need help with a complex topic? Our Gemini-powered AI is ready to assist you instantly.</p>
                <button 
                  onClick={() => setActiveTab('ai-chat')}
                  className="bg-white/20 hover:bg-white/30 backdrop-blur-md px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all"
                >
                  <MessageSquare size={16} /> Open Chat
                </button>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4">
                  <FileText className="text-orange-600 w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">Form Submissions</h3>
                <p className="text-slate-500 text-sm mb-6">You have 3 active forms awaiting your input. Complete them to earn extra badges.</p>
                <button 
                  onClick={() => setActiveTab('forms')}
                  className="text-indigo-600 text-sm font-bold hover:underline flex items-center gap-1"
                >
                  View Forms <ChevronRight size={14} />
                </button>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                  <Shield className="text-green-600 w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">Security & Progress</h3>
                <p className="text-slate-500 text-sm mb-6">Your profile is 100% complete. Keep it up and maintain your streak of 5 days!</p>
                <div className="flex items-center gap-2 text-green-600 text-sm font-bold">
                  <CheckCircle2 size={16} /> Verified Account
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'quizzes' && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Learning Quizzes</h2>
              <div className="flex gap-2">
                <input 
                  id="quizTopic"
                  type="text" 
                  placeholder="Enter any topic..." 
                  className="px-4 py-2 border border-slate-200 rounded-lg text-sm"
                />
                <button 
                  onClick={() => {
                    const topic = (document.getElementById('quizTopic') as HTMLInputElement).value;
                    if (topic) handleGenerateQuiz(topic);
                  }}
                  disabled={quizLoading}
                  className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center gap-2"
                >
                  {quizLoading ? <Loader2 className="animate-spin w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
                  Generate Quiz
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { title: 'General Knowledge', category: 'General', icon: '🌍' },
                { title: 'Science & Nature', category: 'Science', icon: '🔬' },
                { title: 'Information Technology', category: 'CS', icon: '💻' },
                { title: 'Mathematics Essentials', category: 'Math', icon: '🔢' },
                { title: 'History & Civics', category: 'History', icon: '🏛️' },
              ].map((q, i) => (
                <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-lg transition-all cursor-pointer group">
                  <div className="text-4xl mb-4">{q.icon}</div>
                  <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded uppercase">{q.category}</span>
                  <h3 className="text-xl font-bold mt-2 mb-4 group-hover:text-indigo-600 transition-colors">{q.title}</h3>
                  <p className="text-slate-500 text-sm mb-6">Challenge yourself with 10 questions and climb the leaderboard.</p>
                  <button 
                    onClick={() => handleGenerateQuiz(q.title)}
                    className="w-full bg-slate-50 text-slate-900 py-3 rounded-xl font-bold hover:bg-slate-900 hover:text-white transition-all"
                  >
                    Start Quiz
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'quiz-player' && activeQuiz && (
          <QuizPlayer quiz={activeQuiz} onFinish={(score) => console.log('Final Score:', score)} />
        )}

        {activeTab === 'forms' && (
          <div className="max-w-2xl mx-auto space-y-8">
            <h2 className="text-2xl font-bold">Active Forms</h2>
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="text-xl font-bold mb-6">User Satisfaction & Feedback</h3>
              <form onSubmit={handleFeedbackSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">How do you feel about the AI features?</label>
                  <textarea 
                    rows={4}
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                    placeholder="Tell us what you think..."
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all"
                >
                  Submit for AI Analysis
                </button>
              </form>
              
              {analysisResult && (
                <div className="mt-8 p-6 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center gap-2 mb-3 text-indigo-600 font-bold">
                    <Sparkles size={18} /> Gemini Feedback Analysis
                  </div>
                  <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">{analysisResult}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'ai-chat' && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">Personal AI Tutor</h2>
            <AIChat />
          </div>
        )}

        {activeTab === 'admin' && user.role === UserRole.ADMIN && (
          <AdminDashboard />
        )}
      </main>
    </div>
  );
};

export default App;
