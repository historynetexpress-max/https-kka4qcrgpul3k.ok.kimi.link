
import React, { useState } from 'react';
import { Quiz, Question } from '../types';
import { CheckCircle2, XCircle, ChevronRight, RefreshCcw, Award } from 'lucide-react';

interface QuizPlayerProps {
  quiz: Quiz;
  onFinish: (score: number) => void;
}

const QuizPlayer: React.FC<QuizPlayerProps> = ({ quiz, onFinish }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);

  const currentQuestion = quiz.questions[currentIdx];

  const handleSelect = (idx: number) => {
    if (isSubmitted) return;
    setSelectedOption(idx);
  };

  const handleSubmit = () => {
    if (selectedOption === null) return;
    
    if (selectedOption === currentQuestion.correctAnswer) {
      setScore(prev => prev + 1);
    }
    setIsSubmitted(true);
  };

  const handleNext = () => {
    if (currentIdx < quiz.questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
      setSelectedOption(null);
      setIsSubmitted(false);
    } else {
      setCompleted(true);
      onFinish(score + (selectedOption === currentQuestion.correctAnswer ? 1 : 0));
    }
  };

  if (completed) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-8 text-center max-w-lg mx-auto">
        <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Award className="w-10 h-10 text-indigo-600" />
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Quiz Completed!</h2>
        <p className="text-slate-500 mb-6">You've successfully finished {quiz.title}.</p>
        <div className="text-5xl font-extrabold text-indigo-600 mb-8">
          {score} / {quiz.questions.length}
        </div>
        <button
          onClick={() => window.location.reload()}
          className="bg-indigo-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-indigo-700 transition-all flex items-center gap-2 mx-auto"
        >
          <RefreshCcw size={18} /> Take Another Quiz
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">{quiz.category}</span>
          <span className="text-sm text-slate-500">Question {currentIdx + 1} of {quiz.questions.length}</span>
        </div>
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div 
            className="bg-indigo-600 h-full transition-all duration-300" 
            style={{ width: `${((currentIdx + 1) / quiz.questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6 md:p-8">
        <h3 className="text-xl font-bold text-slate-800 mb-8">{currentQuestion.text}</h3>
        
        <div className="space-y-4 mb-8">
          {currentQuestion.options.map((opt, idx) => {
            let statusClass = "border-slate-200 hover:border-indigo-300 hover:bg-indigo-50";
            if (isSubmitted) {
              if (idx === currentQuestion.correctAnswer) statusClass = "border-green-500 bg-green-50";
              else if (idx === selectedOption) statusClass = "border-red-500 bg-red-50";
              else statusClass = "opacity-50 border-slate-200";
            } else if (selectedOption === idx) {
              statusClass = "border-indigo-600 bg-indigo-50";
            }

            return (
              <button
                key={idx}
                disabled={isSubmitted}
                onClick={() => handleSelect(idx)}
                className={`w-full p-4 text-left border-2 rounded-xl transition-all flex items-center justify-between group ${statusClass}`}
              >
                <span className="font-medium">{opt}</span>
                {isSubmitted && idx === currentQuestion.correctAnswer && <CheckCircle2 className="text-green-500" size={20} />}
                {isSubmitted && idx === selectedOption && idx !== currentQuestion.correctAnswer && <XCircle className="text-red-500" size={20} />}
              </button>
            );
          })}
        </div>

        <div className="flex justify-end">
          {!isSubmitted ? (
            <button
              onClick={handleSubmit}
              disabled={selectedOption === null}
              className="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 disabled:opacity-50 transition-all"
            >
              Check Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 flex items-center gap-2 transition-all"
            >
              {currentIdx === quiz.questions.length - 1 ? 'Finish Quiz' : 'Next Question'} <ChevronRight size={18} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizPlayer;
