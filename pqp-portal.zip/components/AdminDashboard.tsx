
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { Users, BookOpen, FileText, TrendingUp, AlertCircle } from 'lucide-react';

const data = [
  { name: 'Mon', quizzes: 400, forms: 240 },
  { name: 'Tue', quizzes: 300, forms: 139 },
  { name: 'Wed', quizzes: 200, forms: 980 },
  { name: 'Thu', quizzes: 278, forms: 390 },
  { name: 'Fri', quizzes: 189, forms: 480 },
  { name: 'Sat', quizzes: 239, forms: 380 },
  { name: 'Sun', quizzes: 349, forms: 430 },
];

const AdminDashboard: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Users', val: '1,284', icon: Users, color: 'indigo' },
          { label: 'Quizzes Taken', val: '4,821', icon: BookOpen, color: 'purple' },
          { label: 'Forms Submitted', val: '892', icon: FileText, color: 'orange' },
          { label: 'User Retention', val: '84%', icon: TrendingUp, color: 'green' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
              <h4 className="text-2xl font-bold text-slate-900 mt-1">{stat.val}</h4>
            </div>
            <div className={`w-12 h-12 rounded-lg bg-${stat.color}-50 flex items-center justify-center`}>
              <stat.icon className={`text-${stat.color}-600 w-6 h-6`} />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold mb-6">Weekly Activity</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorQuizzes" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="quizzes" stroke="#4f46e5" fillOpacity={1} fill="url(#colorQuizzes)" />
                <Area type="monotone" dataKey="forms" stroke="#9333ea" fillOpacity={1} fill="#9333ea20" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold mb-6">User Distribution</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="quizzes" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-200 flex justify-between items-center">
          <h3 className="text-lg font-bold">Recent Submissions</h3>
          <button className="text-indigo-600 font-semibold text-sm hover:underline">View All</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Action</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                { name: 'Rahul Sharma', action: 'Took GK Quiz', status: 'Completed', date: '2 mins ago' },
                { name: 'Priya Verma', action: 'Submitted Feedback', status: 'Pending Review', date: '15 mins ago' },
                { name: 'Amit Kumar', action: 'Took Python Quiz', status: 'Completed', date: '1 hour ago' },
                { name: 'Sneha Gupta', action: 'Admin Login', status: 'Authorized', date: '3 hours ago' },
              ].map((row, i) => (
                <tr key={i} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-medium">{row.name}</td>
                  <td className="px-6 py-4 text-slate-600">{row.action}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      row.status === 'Completed' ? 'bg-green-100 text-green-700' :
                      row.status === 'Pending Review' ? 'bg-orange-100 text-orange-700' :
                      'bg-indigo-100 text-indigo-700'
                    }`}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-400 text-sm">{row.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
